# Mapa de Evidencia en Cannabis Medicinal — IETS

Aplicación web que muestra, en una matriz de intervenciones por desenlaces, qué se ha
estudiado sobre cannabis medicinal, con qué certeza y dónde están los vacíos de
investigación. Incluye un panel de administración para mantener los datos.

Construida con Flask y SQLite; el frontend es HTML, CSS y JavaScript sin frameworks.

---

## Puesta en marcha local

```bash
pip install -r requirements.txt
python app.py
```

Queda disponible en `http://localhost:5000`. La base de datos `mapa_cannabis.db` se crea
y se puebla sola la primera vez; si el archivo ya existe, no se sobrescribe.

Para regenerar la base desde cero con los datos semilla:

```bash
python database.py
```

## Despliegue en Render

El repositorio trae `render.yaml` y `Procfile`. Al conectar el repositorio, Render toma la
configuración automáticamente:

- **Build:** `pip install -r requirements.txt`
- **Start:** `gunicorn app:app --bind 0.0.0.0:$PORT`
- **Disco:** monta un volumen en `/var/data` y define `MAPA_DB_PATH=/var/data/mapa_cannabis.db`

El disco persistente es indispensable: sin él, cada despliegue borra los cambios hechos
desde el panel de administración y vuelve a cargar los datos semilla.

Antes de compartir el enlace por WhatsApp, completa `og:url` y `og:image` en
`templates/index.html`; las etiquetas ya están puestas pero vacías.

---

## Estructura

```
app.py                      rutas y API
database.py                 esquema SQLite, carga inicial y listas controladas
data/taxonomia.py           filas y columnas del mapa
data/estudios_semilla.py    55 estudios iniciales y marco normativo colombiano
templates/index.html        mapa público
templates/admin.html        panel de administración
static/css/app.css          identidad visual del IETS
static/js/mapa.js           matriz, filtros, modal y exportación
static/js/admin.js          tablas, formularios y llamadas a la API
```

## Modelo de datos

| Tabla | Contenido |
|---|---|
| `categorias_intervencion` | agrupación de las filas (C1–C4) |
| `intervenciones` | filas del mapa (I1–I13) |
| `dominios_desenlace` | agrupación de las columnas (D1–D4) |
| `desenlaces` | columnas del mapa (O1–O15) |
| `estudios` | referencias con metadatos y estado de verificación |
| `estudio_intervencion`, `estudio_desenlace` | relaciones muchos a muchos |
| `normativa` | marco normativo mostrado en «Cómo leerlo» |

Un estudio con 3 intervenciones y 4 desenlaces marca 12 celdas del mapa. Las celdas sin
ningún estudio se dibujan rayadas: son los vacíos de investigación.

El eje visual de cada estudio se deriva de su tipo:

- **Círculo turquesa — síntesis de evidencia:** revisión sistemática, revisión sistemática
  con metaanálisis, revisión de revisiones, revisión narrativa, mapa de evidencia, guía de
  práctica clínica, evaluación de tecnología sanitaria.
- **Círculo amarillo — estudios primarios:** ensayo clínico aleatorizado, ensayo no
  aleatorizado, estudio observacional, estudio cualitativo, evaluación económica, serie o
  reporte de casos.

Para cambiar esta clasificación, edita `TIPOS_SINTESIS` y `TIPOS_PRIMARIO` en `database.py`.

---

## Verificación de los datos semilla

**Todos los registros iniciales están marcados como «Por verificar».** Corresponden a
literatura real y ampliamente citada en el campo, pero los metadatos bibliográficos
(autoría exacta, año, volumen, DOI) no fueron confirmados uno a uno contra la fuente
primaria. Varios registros se dejaron sin DOI a propósito en lugar de arriesgar un
identificador incorrecto.

Flujo sugerido antes de publicar:

1. Filtra por «Por verificar» en el panel de administración.
2. Abre cada registro, confirma la referencia contra la fuente y corrige lo que falte.
3. Cambia su estado a **Verificada**. El mapa público muestra ese estado en el detalle de
   cada estudio.

## API

| Método | Ruta | Uso |
|---|---|---|
| GET | `/api/datos` | estructura completa y estudios con sus relaciones |
| GET | `/api/catalogos` | listas controladas de los formularios |
| GET | `/api/salud` | verificación rápida del servicio |
| POST / PUT / DELETE | `/api/estudios[/<id>]` | CRUD de estudios |
| POST / PUT / DELETE | `/api/intervenciones[/<id>]` | CRUD de filas |
| POST / PUT / DELETE | `/api/desenlaces[/<id>]` | CRUD de columnas |
| POST / PUT / DELETE | `/api/categorias[/<id>]` | CRUD de categorías |
| POST / PUT / DELETE | `/api/dominios[/<id>]` | CRUD de dominios |
| POST | `/api/importar` | carga por lotes desde JSON |

Formato de la carga por lotes (las intervenciones y los desenlaces se referencian por
código):

```json
{"estudios": [{
  "titulo": "Título del estudio",
  "autores": "Apellido AA; Apellido BB",
  "anio": 2024,
  "fuente": "Nombre de la revista",
  "tipo_estudio": "Ensayo clínico aleatorizado",
  "certeza": "Moderada",
  "hallazgo": "Favorable",
  "intervenciones": ["I2", "I7"],
  "desenlaces": ["O1", "O11"]
}]}
```

---

## Uso del mapa

- **Clic en una celda:** abre la lista de estudios de ese cruce, ordenada por certeza.
- **Clic en el nombre de una fila o columna:** muestra todos los estudios de esa
  intervención o desenlace.
- **Vistas:** burbujas (volumen por eje), densidad (total por celda) y certeza máxima
  (mejor certeza reportada en la celda).
- **Resaltar vacíos:** marca en rojo suave las celdas sin evidencia.
- **Filtros:** se reflejan en la dirección web, de modo que una vista filtrada se puede
  compartir por enlace.
- **Descargar CSV:** exporta los estudios que cumplen los filtros activos, con separador
  punto y coma y BOM para que Excel en español lo abra bien.
- **Teclado:** `/` enfoca la búsqueda; las flechas recorren la matriz; `Esc` cierra.

## Pendientes conocidos

- El panel de administración **no tiene autenticación**: cualquiera con el enlace puede
  modificar los datos. Antes de exponerlo públicamente conviene protegerlo, como mínimo con
  autenticación básica o restricción por red.
- `og:url` y `og:image` están vacíos.
- No hay historial de cambios ni papelera: al eliminar un registro se borra de inmediato.
